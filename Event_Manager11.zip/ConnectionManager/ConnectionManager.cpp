//
// Created by aziz on 09.10.21.
//

#include "ConnectionManager.h"
#include "../Protocols/S7Protocol.h"
#include "../Protocols/MasterProtocol.h"
#include "../Protocols/GpsProtocol.h"
#include "../Protocols/ServerProtocol.h"
#include "../Protocols/SubscriberProtocol.h"
#include "../Protocols/PublisherProtocol.h"
#include "../Protocols/KeyProtocol.h"
#include "../Protocols/MouseProtocol.h"
#include "../Protocols/CentralProtocol.h"

#include "../GateWay/Connection/ConnectionEdge.h"
#include "../GateWay/ConvertS/Convert.h"

#include "../GateWay/Node/MqttTag.h"
#include "../GateWay/Node/S7Tag.h"
#include "../GateWay/Node/ModBusTag.h"
#include "../GateWay/Node/CoapTag.h"
#include "../GateWay/Node/EdgeTag.h"

#include "../GateWay/Node/NodeList.h"
#include "../GateWay/Listener.h"

extern std::vector<Connection*> ConnectionS;
extern std::vector<Convert> ConvertS;
extern std::vector<ProtocolS::Protocol*> ListenerS;
extern ProtocolS::NodeList nodeList;
extern GateWay::LISTENer::Listener ll;

using mqtt_sub = ProtocolS::Mqtt::SubscriberProtocol;
using mqtt_pub = ProtocolS::Mqtt::PublisherProtocol;

auto cb_lose = [](const std::string& s)
{
    std::cerr << "*** Connection Lost  ***"<< s << std::endl;
    ERROR::Error err{ERR_MQTT, s, "design connection manager", ERROR::ErrorType::LOGICAL, 6};
    errorManager.AddError(err);
};

auto errHandMqtt = [](std::string /*strErr*/)
{
    ERROR::Error err{ERR_MQTT, "Mqtt err", "debug Mqtt", ERROR::ErrorType::RUN_TIME, 7};
    errorManager.AddError(err);
};
auto errHandS7 = [](std::string strErr)
{
    ERROR::Error err{ERR_S7, strErr, "debug S7", ERROR::ErrorType::RUN_TIME, 7};
    errorManager.AddError(err);
};

void CONNECTION::ConnectionManager::AddConnection(ProtocolS::Protocol* pro)
{
    std::cout<< "Adding new configuration ...... " << std::endl;
    // bool exists = false;
    // for (auto x : ListenerS){
    //     if(x.)

    // }
    ListenerS.push_back(pro);
    ll.SetNodes(pro);
}

void CONNECTION::ConnectionManager::AddConvert(Convert Conn)
{
    std::cout<< "Adding new Convert:" << Conn.source() << std::endl;
    ConvertS.push_back(Conn);
}


void CONNECTION::ConnectionManager::Create()
{
    for (auto p:ConnectionS) {

        switch (p->IProtocol) {
        case ProtocolIIOT::S7 : {
            std::cout << "config S7" << std::endl;
            auto m = reinterpret_cast<ConnectionS7*>(p);
            ProtocolS::S7::S7Protocol *s7{new ProtocolS::S7::S7Protocol};
            s7->setErrCallBack(errHandS7);
            s7->Create(m);

            ProtocolS::Node n;
            n.first = m->Name.Value;
            for (auto t : m->NodeS ) {
                auto mq = reinterpret_cast<xmlS7*>(t);
                ProtocolS::S7Tag* mn{new ProtocolS::S7Tag(mq)};
                mn->conn = m;
                n.second.push_back(mn);
            }
            nodeList.push_back(std::move(n));
            for (auto [i, n]:nodeList) {
                if (strcmp(i.c_str(), m->Name.Value.c_str())==0)
                    for (auto t:n) {
                        t->setSubject(s7);
                        t->TagType = ProtocolIIOT::S7;
                    }
            };
            ListenerS.push_back(s7);
        }
        break;
        case ProtocolIIOT::EDGE : {
            std::cout << "config Edge" << std::endl;
            // auto m = reinterpret_cast<ConnectionEdge*>(p);
            // ProtocolS::CentralProtocol *central{new ProtocolS::CentralProtocol};
            // central->Create(m);

            // ProtocolS::Node n;
            // n.first = m->Name.Value;
            // for (auto t : m->NodeS ) {
            //     auto mq = reinterpret_cast<xmlEdge*>(t);
            //     ProtocolS::EdgeTag* mn{new ProtocolS::EdgeTag(mq)};

            //     n.second.push_back(mn);
            // }
            // nodeList.push_back(std::move(n));
            // for (auto [i, n]:nodeList) {
            //     if (strcmp(i.c_str(), m->Name.Value.c_str())==0)
            //         for (auto t:n) {
            //             t->setSubject(central);
            //             t->TagType = ProtocolIIOT::EDGE;
            //         }
            // };
            // ListenerS.push_back(central);


        }
        break;
        case ProtocolIIOT::MQTT : {
            std::cout << "config MQTT" << std::endl;
            auto m = reinterpret_cast<ConnectionMqtt*>(p);
            mqtt_sub *node{new mqtt_sub{m}};
            node->setErrCallBack(errHandMqtt);

            // node->SetHandler(cb_lose,false);

            ProtocolS::Node n;
            n.first = m->Name.Value;
            for (auto t : m->NodeS ) {
                auto mq = reinterpret_cast<xmlMqtt*>(t);
                ProtocolS::MqttTag* mn{new ProtocolS::MqttTag(mq)};
                mn->conn = m;
                n.second.push_back(mn);
            }
            nodeList.push_back(std::move(n));

            for (auto [i,n]:nodeList) {
                if(strcmp(i.c_str(),m->Name.Value.c_str())==0)
                    for (auto t:n) {
                        t->setSubject(node);
                        t->TagType = ProtocolIIOT::MQTT;
                    }
            };
            ListenerS.push_back(node);
        }
        break;
        case ProtocolIIOT::MODBUS : {
            std::cout << "config Modbus" << std::endl;
            auto m = reinterpret_cast<ConnectionModbus*>(p);
            ProtocolS::ModBus::MasterProtocol *master{new ProtocolS::ModBus::MasterProtocol()};
            master->Create(m);

            ProtocolS::Node n;
            n.first = m->Name.Value;
            for (auto t : m->NodeS ) {
                auto mq = reinterpret_cast<xmlModBus*>(t);
                ProtocolS::ModBusTag* mn{new ProtocolS::ModBusTag(mq)};
                mn->conn = m;
                n.second.push_back(mn);
            }
            nodeList.push_back(std::move(n));

            for (auto [i,n]:nodeList) {
                if(strcmp(i.c_str(),m->Name.Value.c_str())==0)
                    for (auto t:n) {
                        t->setSubject(master);
                        t->TagType = ProtocolIIOT::MODBUS;
                    }
            };

            ListenerS.push_back(master);
        }
        break;
        case ProtocolIIOT::GPS : {
            /*auto ConGPS = reinterpret_cast<ConnectionGPS*>(p);
            GPs::GpsProtocol *gps{new GPs::GpsProtocol(ConGPS)};
            gps->setGpsCb(gps_cb02);
            ListenerS.push_back(gps);*/
            std::cout << "\nGPS";
        }
        break;
        case ProtocolIIOT::SNMP : {

            /* using namespace ProtocolS::SnMP;
             SnmpProtocol* snmp{new SnmpProtocol()};
             snmp->SetConnection(p);
             snmp->SetType(SNMPpp::PDU::kGet);
             snmp->SetPduCb(pdu_h);
             snmp->SetActCallback(act_h);
             ListenerS.push_back(snmp);*/
            std::cout << "SNMP";
        }
        break;
        case ProtocolIIOT::COAP : {
            /*using namespace ProtocolS::COAP;
            auto m = reinterpret_cast<ConnectionCoap*>(p);
            ServerProtocol* node{new ServerProtocol};
            node->Create(p);

            ProtocolS::Node n;
            n.first = m->Name.Value;
            for (auto t : m->NodeS ) {
               auto mq = reinterpret_cast<xmlCoap*>(t);
               ProtocolS::CoapTag* mn{new ProtocolS::CoapTag(mq)};
               n.second.push_back(mn);
            }
            nodeList.push_back(std::move(n));

            for (auto [i,n]:nodeList) {
               if(strcmp(i.c_str(),m->Name.Value.c_str())==0)
                   for (auto t:n) {
                       t->setSubject(node);
                   }
            };
            node->Open(Connection *Conn);
            p->print();
            ListenerS.push_back(node);*/
            std::cout << "\ncoap";
        }

        break;
        default:
            std::cout << "\ncheck type connection";
            break;
        }
        std::cout <<"\n................................................\n";
    }    

    // ListenerS.push_back(new ProtocolS::RECEIVER::ReceiverProtocol );
    //ListenerS.push_back(new ProtocolS::KEY::KeyProtocol);
    //ListenerS.push_back(new ProtocolS::MOUSE::MouseProtocol );


}