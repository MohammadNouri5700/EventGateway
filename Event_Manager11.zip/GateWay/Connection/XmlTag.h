//
// Created by aziz on 15.09.21.
//

#ifndef XML_TAG_H
#define XML_TAG_H
#include <string>
#include <map>

template<class tValue>
struct XmlTag {
    tValue Value{};
};


#endif //XML_TAG_H
