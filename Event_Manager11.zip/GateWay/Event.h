//
// Created by aziz on 21.09.21.
//

#ifndef EVENT_MANAGER_EVENT_H
#define EVENT_MANAGER_EVENT_H
#include <boost/signals2.hpp>
#include <functional>
#include <string>
#include "Data.h"
#include "Node/Tag.h"
enum class TYPE {Null=0, PRINT, MQTT, COAP, GPS, S7, MODBUS, SNMP, COMMAND, EDGE, UPDATE, SEND, RECEIVE, TIMER, WIFI_SCAN, WIFI_CON, ERROR};

using SignalType = boost::signals2::signal<void(Data*, ProtocolS::Tag*)>;
using FunctionType = std::function<void(Data*, ProtocolS::Tag*)>;

struct Event {
    boost::shared_ptr<Data> data{}; //TODO: shared_ptr
    ProtocolS::Tag* Destination{};
    boost::shared_ptr<SignalType> aSignal{new SignalType };
    TYPE type;

    Event() : data(nullptr), Destination() {}
    Event( Data *data) : data(data) {}
    Event( Data *data, TYPE type) : data(data), type(type) {}
    Event( Data *data, TYPE type, ProtocolS::Tag *dest): data(data), type(type), Destination(dest) {}
    Event( Data *data, TYPE type, ProtocolS::Tag *dest, FunctionType &f) : data(data), type(type), Destination(dest)
    {
        aSignal->connect(f);
    }
    void Run()
    {
        (*aSignal)(data.get(), Destination);
    };
    void SetSignal(const FunctionType &f);

};

using ItreatorType = std::list<Event>::iterator;


#endif //EVENT_MANAGER_EVENT_H
