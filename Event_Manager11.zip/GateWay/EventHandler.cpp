//
// Created by aziz on 04.12.21.
//

#include "EventHandler.h"

extern std::mutex end_mutex;

GateWay::EVENT::HANDLER::EventHandler::EventHandler()
{
}

GateWay::EVENT::HANDLER::EventHandler::~EventHandler()
{
}
auto as_integer(TYPE const value)
    -> typename std::underlying_type<TYPE>::type
{
    return static_cast<typename std::underlying_type<TYPE>::type>(value);
}
void GateWay::EVENT::HANDLER::EventHandler::Act()
{
    auto free_b = [this](ItreatorType begin, ItreatorType end, size_t n)
    {
        size_t i = 0;
        std::cout << "<(" << n << ")>\n";

        auto it = std::next(begin);
        {
            const std::lock_guard<std::mutex> lock(end_mutex);
            EventList.erase(begin);
        }
        while (it != end)
        {
            i++;
            auto e = *it;
            TYPE t = e.type;
            std::cout << "main switch" << (int)t << "\n";
            switch (t)
            {
            case TYPE::MQTT:
                e.SetSignal(MqttCB01);
                break;
            case TYPE::MODBUS:
                e.SetSignal(ModbusCB01);
                break;
            case TYPE::S7:
                e.SetSignal(S7CB01);
                break;
            case TYPE::PRINT:
                e.SetSignal(PrintCB01);
                break;
            case TYPE::UPDATE:
                e.SetSignal(Updater);
                break;
            // case TYPE::WIFI_SCAN:
            //     e.SetSignal(Wifi_scan);
            //     break;
            // case TYPE::WIFI_CON:
            //     e.SetSignal(wifi_Connect);
            //     break;
            case TYPE::ERROR:
            {
                /*e.SetSignal(PrintCB01);
                e.SetSignal(Notyfy01);
                e.SetSignal(message01);*/
            }
            break;
            default:
                break;
            }
            // std::cout<< "Dest is"<<as_integer(e.Destination.type) <<std::endl;
            //  if (TYPE::MQTT == e.Destination.type)
            //      e.SetSignal(MqttCB01);

            // if (TYPE::MODBUS == e.Destination.type)
            //     e.SetSignal(ModbusCB01);

            if (TYPE::ERROR == e.type)
            {
                e.SetSignal(PrintCB01);
                e.SetSignal(Notyfy01);
                // e.SetSignal(message01);
            }
            PoolEvent.Post(std::bind([](Event e)
                                     { e.Run(); },
                                     e));
            it = EventList.erase(it);
        }
        {
            const std::lock_guard<std::mutex> lock(end_mutex);
            EventList.erase(end);
        }

        std::cout << " (" << n << ") = " << i << std::endl;
    };
    auto rel = [this, &free_b]()
    {
        if (!BlockS.empty())
        {
            auto block = BlockS.front();
            if (std::next(block.aBegin) != block.aEnd)
            {
                PoolQueue.Post(std::bind(free_b, std::move(block.aBegin), std::move(block.aEnd), block.aNum));
            }
            else
            {
                const std::lock_guard<std::mutex> lock(end_mutex);
                EventList.erase(block.aBegin);
                EventList.erase(block.aEnd);
            }
            BlockS.pop_front();
        }
    };

    Caller.push_task("re", 1s, rel);

    Caller.run();
    PoolEvent.Wait();
    PoolQueue.Wait();
}
