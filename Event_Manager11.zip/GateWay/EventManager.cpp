//
// Created by aziz on 04.08.21.
//

#include "EventManager.h"
#include <algorithm>
#include <chrono>
#include <iostream>
#include <vector>
#include <mutex>
#include "Data.h"
#include "../GateWay/Node/NodeList.h"

#include "../Entity/command/command.h"



extern bool connected;

std::list<Event> EventList;

extern ProtocolS::NodeList nodeList;

std::deque<BlockType> BlockS;

std::mutex end_mutex;

GateWay::EVENT::MANAGER::EventManager::EventManager() {}

GateWay::EVENT::MANAGER::EventManager::~EventManager()
{

}
void GateWay::EVENT::MANAGER::EventManager::Act()
{
    Event begin_e{new ProtocolData{"begin " + std::to_string(NumQueue + 1), nullptr}};
    Begin = EventList.insert(EventList.begin(), std::move(begin_e));
    std::cout<< "\nmanager\n............" << std::endl;
    std::cout<< "\n........... all event............" << std::endl;
    ///.............................................................................................
    auto DB =[this]() {
        if (EventList.size() >= 1 && Begin != EventList.end()) {
            const std::lock_guard<std::mutex> lock(end_mutex);
            ItreatorType it = EventList.end();
            if (Begin != it) {
                Event end_e{new ProtocolData{"end " + std::to_string(NumQueue), nullptr}};
                auto it_end = EventList.insert(it, std::move(end_e));
                BlockType  b{Begin, it_end, NumQueue};
                Event begin_e{new ProtocolData{"begin " + std::to_string(NumQueue + 1), nullptr}};
                Begin = EventList.insert(it, std::move(begin_e));
                NumQueue++;
                BlockS.push_back(b);
            } else {
                std::cout <<" Begin == end  ";
            }
        }
    };
    std::cout << "size : " << nodeList.size() << std::endl;
    for (auto node : nodeList) {
        auto tags = node;
        for (auto tag : tags.second) {
            std::cout << tag->strGetName() << " : " << tag->Timer.Value << std::endl;
            if (tag->Timer.Value > 0) {
                AddTimer(tag);

            }
        }
    }
    // auto ack =[]() {
    //     if (!connected) {
    //         commandEntity con;
    //         con.i_commandId = "acknowledgment";
    //         con.str_command = "INIT";
    //         con.str_response= "init";
    //         std::string ss =to_string(con.toJson());
    //         Event e{new ProtocolData{ss}, {TYPE::COMMAND, "" }, {TYPE::SEND, ""}};
    //         EventList.push_back(std::move(e));
    //     }
    // };

    Caller.push_task("db", 1s, DB );
    //Caller.push_task("ACK", 8s, ack );

    Caller.run();
}

void GateWay::EVENT::MANAGER::EventManager::AddTimer(ProtocolS::Tag *tag)
{
    auto Timer =[](ProtocolS::Tag *tag) {

        (void)tag; //TODO
        /*  Event e{new TagData{tag}, {TYPE::TIMER,"TIMER" }, {TYPE::UPDATE,tag->strGetName()}};
          EventList.push_back(std::move(e));*/
    };

    Caller.push_task(tag->strGetName(), tag->Timer.Value * 1s, std::bind(Timer, tag));
}

// void GateWay::EVENT::MANAGER::EventManager::addEvent(Event e)
// {
//     EventList.push_back(std::move(e));
// }



