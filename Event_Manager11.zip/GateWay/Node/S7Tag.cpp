//
// Created by aziz on 11.10.21.
//

#include "S7Tag.h"
#include <cstring>
#include "../Event.h"
#include "../GateWay/ConvertS/Convert.h"
#include "../GateWay/Node/NodeList.h"

extern std::list<Event> EventList;
extern std::vector<Convert> ConvertS;
using Byte = uint8_t;

void ProtocolS::S7Tag::setSubject(ProtocolS::Protocol *subject)
{
    Tag::setSubject(subject);
}

void ProtocolS::S7Tag::SendEvent()
{
    std::string v;
    Event b;
    if (strcmp(ValueType.Value.c_str(), "float")==0) {
        float  Res; memcpy (&Res, Value, 4);
        v = std::to_string(Res);
    }
    else if (strcmp(ValueType.Value.c_str(), "int")==0) {
        v = std::to_string(*((int32_t*)Value));
    }
    else if (strcmp(ValueType.Value.c_str(), "int16")==0) {
        v = std::to_string(*((int16_t*)Value));
    }
    else if (strcmp(ValueType.Value.c_str(), "bool")==0) {
        v = (*((bool*)Value))?"true":"false";
    }
    Event e{new ProtocolData{v, nullptr}, TYPE::PRINT};
    for (auto p: ConvertS) {
        if (p.source() == this->Name.Value) {
            auto t = findTag(p.distS()[0]);
           
            switch (t->conn->IProtocol)
            {
            case ProtocolIIOT::MQTT:
                b = Event(new ProtocolData{v,Value}, TYPE::MQTT, t);
                EventList.push_back(std::move(b));
                break;

            case ProtocolIIOT::MODBUS:
                b = Event(new ProtocolData{v,Value}, TYPE::MODBUS, t);
                EventList.push_back(std::move(b));
            default:
                break;
            }
            
            
        }
    }
    EventList.push_back(std::move(e));
}

void ProtocolS::S7Tag::Print()
{
    Tag::Print();
    std::cout << "Starting Address : " << StartingAddress.Value <<"\n"
              << "Bit Number : " << BitNumber.Value <<"\n"
              << "Signal State : " << SignalState.Value <<"\n";
}

ProtocolS::S7Tag::~S7Tag()
{

}

ProtocolS::S7Tag::S7Tag(xmlS7 * nS7)
    : Tag(nS7), StartingAddress(nS7->StartingAddress), BitNumber(nS7->BitNumber), SignalState(nS7->SignalState) {}

uint16_t ProtocolS::S7Tag::getStartingAddress() const
{
    return StartingAddress.Value;
}

uint16_t  ProtocolS::S7Tag::getBitNumber() const
{
    return BitNumber.Value;
}

bool ProtocolS::S7Tag::getSignalState() const
{
    return SignalState.Value;
}

void ProtocolS::S7Tag::UpdateValue()
{
    Tag::UpdateValue();
}

int ProtocolS::S7Tag::GetType()
{
    return 10;
}



