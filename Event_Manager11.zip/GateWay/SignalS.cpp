//
// Created by aziz on 30.08.21.
//

#include "SignalS.h"
#include "Event.h"
#include "../Protocols/MasterProtocol.h"
#include "../Protocols/S7Protocol.h"
#include <fstream>
#include "../wireless/wifi.h"
#include "Node/NodeList.h"
#include "config/config.h"
#include "Node/Tag.h"
#include <map>


extern std::list<Event> EventList;
extern std::vector<Connection*> ConnectionS;

FunctionType Updater = [](Data *data, auto)
{
    std::cout << "Updater" << std::endl;
    auto tag = dynamic_cast<TagData*>(data)->tag_;
    tag->UpdateValue();
};

FunctionType message01 = [](Data *data, auto)
{
    std::cout << "message01" << std::endl;
    std::string str;

    auto err = dynamic_cast<ErrorData*>(data)->errData;
    str += std::string{"zenity " };
    str += (err.u8Severity == 0 ? "--error":"--warning");
    str += " --text=";
    str += "\"" + err.strMessage + "\"";
    std::cerr <<str <<"\n";
    system(str.c_str());

};

FunctionType MqttCB01 = [](Data *data, ProtocolS::Tag* dest)
{
    std::cout << "MqttCB01" << std::endl;
    const std::lock_guard<std::mutex> lock(g_i_mutex);
    MqTT::NewPublisher Npub(dest->conn->Address.Value, "test");
    std::cout << "*************** here mqtt  ******************" << dest->conn->Address.Value << std::endl;

    Npub.SetTopic(dest->Name.Value);
    size_t i = 0;
    std::vector<std::string> p;
    p.push_back(std::to_string(i++));
    p.push_back(data->GetString());
    Npub.SetPayload(p);
    Npub.Run();
};

std::map<std::string, ProtocolS::ModBus::MasterProtocol*> modbusMasters;

FunctionType ModbusCB01 = [](Data *data, ProtocolS::Tag* dest)
{
    std::cout << "ModbusCB01" << std::endl;
    ProtocolS::ModBus::MasterProtocol *master;
    if (modbusMasters.find(dest->conn->Address.Value) != modbusMasters.end()) {
        master = modbusMasters[dest->conn->Address.Value];
    } else {
        master = new ProtocolS::ModBus::MasterProtocol();
        modbusMasters[dest->conn->Address.Value] = master;
        master->Open(dest->conn);
    }
    master->Write(data,dest);
};

std::map<std::string, ProtocolS::S7::S7Protocol*> S7s;

FunctionType S7CB01 = [](Data *data, ProtocolS::Tag* dest)
{
    std::cout << "S7CB01" << std::endl;
    ProtocolS::S7::S7Protocol *s7;
    if (S7s.find(dest->conn->Address.Value) != S7s.end()) {
        s7 = S7s[dest->conn->Address.Value];
    } else {
       s7 = new ProtocolS::S7::S7Protocol();
       s7->Create(dest->conn);
       S7s[dest->conn->Address.Value] = s7;
    };
    std::cout << "*************** here S7  ******************" << dest->conn->Address.Value << std::endl;
    s7->Write(data,dest);
};

FunctionType PrintCB01 = [](Data *data, auto)
{
    std::cout << data->GetString() << '\n';
};

FunctionType Notyfy01 = [](Data *data, auto)
{
    std::string str = "notify-send -t 1 " + std::string{"ERROR"} + " \"" + dynamic_cast<ErrorData *>(data)->errData.strMessage + "\"";
    // system(str.c_str());
};

// FunctionType Wifi_scan = [](auto, auto, auto)
// {
//     wifi iw;
//     for (int i = 0; i < 5; i++)
//     {
//         iw.Scan();
//         sleep(1);
//     }
//     std::string d{to_string(iw.toJson())};
//     // iw.print();
//     std::cout << d;

//     Event e{new ProtocolData{d}, {TYPE::COMMAND, ""}, {TYPE::SEND, ""}};
//     EventList.push_back(std::move(e));
// };

// FunctionType wifi_Connect = [](Data *data, auto, auto)
// {
//     auto j = dynamic_cast<jsonData *>(data)->Json;

//     auto essId = j->at("essId").get<std::string>();
//     auto pass = j->at("password").get<std::string>();

//     Connect(essId, pass, "wlp0s20f3");
// };
