#include "mqttservice.h"
#include "mqttclient.h"

using namespace grpc;
using namespace std;

mosqpp::ClientTag ClientTagsFromGrpc(const MqttClients::MqttClient::ClientTag& tag) {
    mosqpp::ClientTag clientTag;
    clientTag.tagName = tag.tagname();
    clientTag.topicName = tag.topicname();
    clientTag.mqttVarType = (mosqpp::MqttVarType)tag.mqttvartype();
    clientTag.onOff = tag.onoff();
    clientTag.systemName = tag.systemname();
    clientTag.clientActions = (mosqpp::ClientActions)tag.clientactions();
    return clientTag;
}

::grpc::Status MqttClientsConfigService::SendMqttClientsConfig(::grpc::ServerContext* context, const ::MqttClients* request, ::ConfigResponse* response) {
    std::cout << "Received MqttClientsConfig request" << std::endl;
    for (auto &mqttClient : request->mqttclient()) {
        auto client = make_shared<mosqpp::MqttClient>(mqttClient.clientid().c_str(),mqttClient.cleansession());
        client->username_pw_set(mqttClient.username().c_str(),mqttClient.userpassword().c_str());
        std::cout << client->connect(mqttClient.hostaddress().c_str(),mqttClient.hostport(),mqttClient.keepalivetime()) << std::endl;
        for (auto &tag : mqttClient.clienttag()) {
            client->AddTag(ClientTagsFromGrpc(tag));
            if (tag.clientactions() == ClientActions::SUB || tag.clientactions() == ClientActions::PUB_SUB) {
                std::cout << client->subscribe(NULL, tag.topicname().c_str(), mqttClient.qos()) << std::endl;
            }
        }
        client->will_set(mqttClient.willtopic().c_str(),mqttClient.willpayload().size(),mqttClient.willpayload().c_str(),mqttClient.willqos(),mqttClient.willretain());
        client->setQos((mosqpp::Qos)mqttClient.qos());
        client->setPublishInterval(mqttClient.publishinterval());
        client->setRetain(mqttClient.retain());
        client->start();
        mosq[mqttClient.clientid()] = client;
    }
    response->set_success(true);
    response->set_errorcode(0);
    response->set_errordesc("success");
    return Status::OK;
}

::grpc::Status MqttBrokerConfigService::SendMqttBrokerConfig(::grpc::ServerContext* context, const ::MqttBorker* request, ::ConfigResponse* response)  {
    std::cout << "I 'm here ..." << std::endl;
    return Status::OK;

}
