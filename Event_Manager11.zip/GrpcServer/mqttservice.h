#pragma once

#include "mqtt.grpc.pb.h"

namespace mosqpp {
class mosquittopp;
}

class MqttClientsConfigService final : public MqttClientsConfig::Service {  
    private: 
        //CONNECTION::ConnectionManager *connMan;
        void ExtractMqttClientConfig();
        virtual ::grpc::Status SendMqttClientsConfig(::grpc::ServerContext* context, const ::MqttClients* request, ::ConfigResponse* response) override;
        std::map<std::string,std::shared_ptr<mosqpp::mosquittopp>> mosq;
    public:
        //MqttClientsConfigService();
};

class MqttBrokerConfigService final : public MqttBrokerConfig::Service {  
    virtual ::grpc::Status SendMqttBrokerConfig(::grpc::ServerContext* context, const ::MqttBorker* request, ::ConfigResponse* response) override;
};
