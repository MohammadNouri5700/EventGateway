#include "s7service.h"
#include <iostream>
#include "../Protocols/S7Protocol.h"
#include "../GateWay/Connection/ConnectionS7.h"
#include "../GateWay/Node/NodeList.h"
#include "../GateWay/Node/S7Tag.h"
using namespace grpc;

SystemSnapSevenConfigService::SystemSnapSevenConfigService(CONNECTION::ConnectionManager *ConnMan){
    connMan = ConnMan;
}

void SystemSnapSevenConfigService::ExtractSnap7Config()
{
    ConnectionS7 *snap7 = new ConnectionS7{};
    for(const PlcConfig x : plcConfig){
        snap7->IProtocol = ProtocolIIOT::S7;
        snap7->Address.Value = x.plcAddress ;//+ ":" + x.plcPort;
        snap7->SlotNumber.Value = 2;

        for(const auto t : x.dataBlockTag){
            xmlS7 *node = new xmlS7;
            node->Name.Value = t.tagName;
            snap7->NodeS.push_back(node);
        }
        for(const auto t : x.ioTag){
            xmlS7 *node = new xmlS7;
            node->Name.Value = t.tagName;
            node->BitNumber.Value = t.bitCount;
            node->StartingAddress.Value = t.wordCount;
            node->ValueType.Value = t.tagType;
            snap7->NodeS.push_back(node);
        }
    }

    auto m = reinterpret_cast<ConnectionS7 *>(snap7);
    ProtocolS::S7::S7Protocol *s7{new ProtocolS::S7::S7Protocol};
    s7->Create(m);

    ProtocolS::Node n;
    n.first = m->Name.Value;
    for (auto t : m->NodeS)
    {
        auto mq = reinterpret_cast<xmlS7 *>(t);
        ProtocolS::S7Tag *mn{new ProtocolS::S7Tag(mq)};
        n.second.push_back(mn);
    }
    nodeList.push_back(std::move(n));
    for (auto [i, n] : nodeList)
    {
        if (strcmp(i.c_str(), m->Name.Value.c_str()) == 0)
            for (auto t : n)
            {
                t->setSubject(s7);
            }
    };
    connMan->AddConnection(s7);
}


::SnapSevenIoTag SnapSevenIOTagGrpc(const ConfigSnapSeven::PLCConfig::IoTag iotag) {
    ::SnapSevenIoTag ioTag;
    ioTag.tagName = iotag.tagname();
    ioTag.tagId = iotag.tagid();
    ioTag.tagType = iotag.tagtype();
    //ioTag.wordCount = iotag.wordcount();
    //ioTag.bitCount = iotag.bitcount();
    ioTag.byteCount = iotag.bytecount();
    return ioTag;
}

::SnapSevenDataBlockTag SnapSevenDataBlockTagGRPC(const ConfigSnapSeven::PLCConfig::DataBlockTag dbtag) {
    ::SnapSevenDataBlockTag dataBlockTag;
    dataBlockTag.tagName = dbtag.tagname();
    dataBlockTag.tagId = dbtag.tagid();
    dataBlockTag.functionCode = dbtag.functioncode();
    //dataBlockTag.count = dbtag.count();
    return dataBlockTag;
}

::grpc::Status SystemSnapSevenConfigService::SendSystemSnapSevenConfig(::grpc::ServerContext* context, const ::ConfigSnapSeven* request, ::SnapSevenConfigResponse* response) {


    std::cout << "Received S7 Config request" << std::endl;    
    PlcConfig tempPlcConfig;
    for (auto &configSnapSeven : request->plcconfig()) {
        tempPlcConfig.plcName = configSnapSeven.plcname();
        tempPlcConfig.plcID = configSnapSeven.plcid();
        tempPlcConfig.plcPort = configSnapSeven.plcport();
        for (auto &tag : configSnapSeven.iotag()) { 
            tempPlcConfig.ioTag.push_back(SnapSevenIOTagGrpc(tag));
        }
        for (auto &tag : configSnapSeven.datablocktag()) { 
            tempPlcConfig.dataBlockTag.push_back(SnapSevenDataBlockTagGRPC(tag));
        }
        plcConfig.push_back(tempPlcConfig);
    }
    ExtractSnap7Config();
    return Status::OK;
}



