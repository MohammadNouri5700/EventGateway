//
// Created by aziz on 24.08.21.
//

#include "S7Protocol.h"
#include "../GateWay/Node/S7Tag.h"
#include <iostream>
#include <string>
#include <algorithm>
extern std::vector<Connection*> ConnectionS;



void ReverseBytes( void *start, int size )
{
    char *istart = (char*)start, *iend = istart + size;
    std::reverse(istart, iend);
}

int Size(std::string str)
{
    if (!strcmp(str.c_str(), "float"))
        return 4;
    else if (!strcmp(str.c_str(), "int16"))
        return 2;
    else if (!strcmp(str.c_str(), "int"))
        return 4;
    else if (!strcmp(str.c_str(), "bool"))
        return 1;
    return 0;
}

ProtocolS::S7::S7Protocol::S7Protocol()
{

}

ProtocolS::S7::S7Protocol::~S7Protocol()
{

}

void ProtocolS::S7::S7Protocol::Listen()
{
            std::cout << "Listen########################" <<std::endl;

    Run();
}

void ProtocolS::S7::S7Protocol::Create(Connection *Conn)
{
    auto cS7 = reinterpret_cast<ConnectionS7 *>(Conn);
    SetAddress(cS7->Address.Value);
    SetRack();
    SetSlot();
    Init();
    auto cb = [this]() -> bool
    {
        for (auto it = Observer.begin(); it != Observer.end(); it++)
        {
            auto tag = reinterpret_cast<S7Tag *>(*it);

            auto size = Size(tag->ValueType.Value);
            byte db[size];
            switch (tag->s7tagType)
            {
            case ProtocolS::S7TagType::DATABLOCKTAG:
                DBRead(tag->getBitNumber(), tag->getStartingAddress(), size, db);
                ReverseBytes(db, size);
                (*it)->setValue(db, size * sizeof(byte));
                break;

            case ProtocolS::S7TagType::IOTAG:
                //tag->
                
                break;

            case ProtocolS::S7TagType::MEMORYTAG:
                MBRead(tag->getStartingAddress(), size, db);
                ReverseBytes(db, size);
                (*it)->setValue(db, size * sizeof(byte));
                break;

                break;

            default:
                DBRead(tag->getBitNumber(), tag->getStartingAddress(), size, db);
                ReverseBytes(db, size);
                (*it)->setValue(db, size * sizeof(byte));

                break;
            }
        }
        return true;
    };
    SetS7Cb(cb);
}

void ProtocolS::S7::S7Protocol::CreateAndWrite(Connection *Conn, Data* data)
{
    std::cout << "++++++++++++" << std::endl;

    auto cS7 = reinterpret_cast<ConnectionS7 *>(Conn);
    SetAddress(cS7->Address.Value);
    SetRack();
    SetSlot();
    Init();

    ProtocolS::S7Tag *tag = (ProtocolS::S7Tag *)FindS7Tag("s7Tag02");
    auto size = Size(tag->ValueType.Value);
    byte db[size];
    int16_t temp = atoi(data->GetString().c_str());
    memcpy(db , &temp , sizeof(temp));
    switch (tag->s7tagType)
    {
    case ProtocolS::S7TagType::DATABLOCKTAG:
        ReverseBytes(db, size);
        std::cout << temp << "++++++ write S7 DATABLOCKTAG++++++" << std::endl;
        DBWrite(tag->getBitNumber(), tag->getStartingAddress(),size, db);
        break;

    case ProtocolS::S7TagType::IOTAG:
        // tag->

        break;

    case ProtocolS::S7TagType::MEMORYTAG:
        break;

    default:
        std::cout << "++++++ write S7 ++++++" << db << std::endl;
        ReverseBytes(db, size);
        DBWrite(tag->getBitNumber(), tag->getStartingAddress(), size, db);
        break;
    }
}

ProtocolS::S7Tag *ProtocolS::S7::S7Protocol::FindS7Tag(std::string name)
{
    for (auto p : ConnectionS)
        if (p->IProtocol == ProtocolIIOT::S7)
            for (auto n : p->NodeS){
                 auto mq = reinterpret_cast<xmlS7*>(n);
                ProtocolS::S7Tag* mn{new ProtocolS::S7Tag(mq)};
                 if (strcmp(mn->Name.Value.c_str(), name.c_str()) == 0)
                    return mn;
            }
               
    std::cout << "S7 Tag :Not Found" << std::endl;
    return nullptr;
}

void ProtocolS::S7::S7Protocol::Open(Connection *Conn)
{
    Connect();
}

void ProtocolS::S7::S7Protocol::Close()
{
    Disconnect();
}

void ProtocolS::S7::S7Protocol::KeepAlive()
{

}

bool ProtocolS::S7::S7Protocol::isOK()
{
    return Connected();
}

void ProtocolS::S7::S7Protocol::Reconnect()
{

}

void ProtocolS::S7::S7Protocol::hasError()
{

}

void ProtocolS::S7::S7Protocol::DataReceived()
{

}

void ProtocolS::S7::S7Protocol::UpdateTag(ProtocolS::Tag *tag)
{
    Protocol::UpdateTag(tag);
}

void ProtocolS::S7::S7Protocol::Write(Data* data,Tag* tag)
{
    Protocol::Write(data,tag);
    ProtocolS::S7Tag *tag_ = (ProtocolS::S7Tag *)tag;
    auto size = Size(tag->ValueType.Value);
    byte db[size];
    int16_t temp = atoi(data->GetString().c_str());
    memcpy(db , &temp , sizeof(temp));
    switch (tag_->s7tagType)
    {
    case ProtocolS::S7TagType::DATABLOCKTAG:
        ReverseBytes(db, size);
        std::cout << temp << "++++++ write S7 DATABLOCKTAG++++++" << std::endl;
        DBWrite(tag_->getBitNumber(), tag_->getStartingAddress(),size, db);
        break;

    case ProtocolS::S7TagType::IOTAG:
        // tag->

        break;

    case ProtocolS::S7TagType::MEMORYTAG:
        break;

    default:
        std::cout << "++++++ write S7 ++++++" << db << std::endl;
        ReverseBytes(db, size);
        DBWrite(tag_->getBitNumber(), tag_->getStartingAddress(), size, db);
        break;
    }
}

