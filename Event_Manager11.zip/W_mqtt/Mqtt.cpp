#include "Mqtt.h"

MqTT::Mqtt::Mqtt(std::string address, std::string id): Client(address, id, mqtt::create_options(MQTTVERSION_5)), TopicS{}, ConOpts{}, ErrCallBack{}
{
}

MqTT::Mqtt::~Mqtt()
{

}

void MqTT::Mqtt::Run()
{
    Init();
    try {
        Connect();
        Act();
        Disconnect();
    } catch (const mqtt::exception& exc) {
        std::cerr << "\n" << exc << std::endl;
        ErrCallBack("mqtt Run");
    }
}

void MqTT::Mqtt::Connect()
{
    try {
        std::cout << "\nConnecting... '" << Client.get_server_uri() << " " << Client.get_client_id() << std::flush;
        Client.connect(ConOpts)->wait();
        std::cout << "  ...OK" << std::endl;
    } catch (const mqtt::exception& exc) {
        std::cerr << "\n" << exc << std::endl;
        ErrCallBack("mqtt connect");
    }



}
void MqTT::Mqtt::Disconnect()
{
    try {
        std::cout << "Disconnecting..." << std::flush;
        Client.disconnect()->wait();
        std::cout << "OK" << std::endl;
    } catch (const mqtt::exception& exc) {
        std::cerr << "\n" << exc << std::endl;
        ErrCallBack("mqtt disconnect");
    }
}


void MqTT::Mqtt::SetHandler(mqtt::async_client::message_handler cb)
{
    Client.set_message_callback(cb);
    std::cout << "OKKKKKKKKKKKKKKKK" << std::endl;
}
void MqTT::Mqtt::SetHandler(mqtt::async_client::connection_handler cb, bool connect_b )
{

    if (connect_b) {
        Client.set_connected_handler(cb);
        std::cout << "OKKKKKKKKKKKKKKKK" << std::endl;

    } else {
        Client.set_connection_lost_handler(cb);
        std::cout << "NOOOOOOOOOOOOO" << std::endl;
    }

}

MqTT::Mqtt::Mqtt(stClient c): Client(c.strAddress, c.strId, mqtt::create_options(MQTTVERSION_5)), TopicS{}, ConOpts{}, ErrCallBack{}
{

}

void MqTT::Mqtt::SetHandler(mqtt::async_client::disconnected_handler cb )
{
    Client.set_disconnected_handler(cb);
}
void MqTT::Mqtt::SetHandler(mqtt::async_client::update_connection_handler cb )
{
    Client.set_update_connection_handler(cb);
}

void MqTT::Mqtt::setErrCallBack(const MqTT::ErrHandler &errCallBack)
{
    ErrCallBack = errCallBack;
}
