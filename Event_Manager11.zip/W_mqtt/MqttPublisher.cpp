//
// Created by aziz on 22.08.21.
//

#include "MqttPublisher.h"
#include <iostream>


MqTT::MqttPublisher::MqttPublisher(std::string adrr, std::string id):Mqtt{adrr, id}
{
    vstrPayloads.clear();
}

MqTT::MqttPublisher::MqttPublisher(stClient client):Mqtt{client.strAddress, client.strId}
{

}

MqTT::MqttPublisher::~MqttPublisher()
{

}

void MqTT::MqttPublisher::MqttPublisher::Init()
{
}

void MqTT::MqttPublisher::Act()
{
    mqtt::topic Topic(Client, strTopicName, QoS);
    mqtt::token_ptr tok;

    for (auto payload : vstrPayloads) {
        try {
            tok = Topic.publish(payload.c_str());
            std::cout << "void MqTT::MqttPublisher::Act() " << "publish "<<payload << std::endl;
        } catch (std::exception &e) {
            std::cout << "void MqTT::MqttPublisher::Act()" << e.what() << std::endl;
        }
    }
    tok->wait();
    std::cout << "OK" << std::endl;
}

void MqTT::MqttPublisher::SetPayload(std::vector<std::string> &p)
{
    for (auto s:p) {
        vstrPayloads.push_back(s);
    }
}