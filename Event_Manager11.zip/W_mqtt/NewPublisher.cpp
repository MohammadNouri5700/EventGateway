//
// Created by aziz on 18.09.21.
//

#include "NewPublisher.h"

void MqTT::NewPublisher::Run()
{
    try {
        Act();
    } catch (const mqtt::exception& exc) {
        std::cerr << "\n" << exc << std::endl;
        ErrCallBack(exc.to_string());
    }
}

MqTT::NewPublisher::NewPublisher(const std::string &addr, const std::string &id) : MqttPublisher(addr, id)
{
    Connect();
}
