#pragma once

#define HOME "/home/user"
