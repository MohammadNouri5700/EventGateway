#include <iostream>
#include "GateWay/Listener.h"
#include "GateWay/EventManager.h"
#include "GateWay/EventHandler.h"
#include "GateWay/Connection/XmlReader.h"
#include "ErrorManager/ErrorManager.h"
#include "GateWay/Node/Tag.h"
#include "GateWay/Node/NodeList.h"
#include "ConnectionManager/ConnectionManager.h"
#include "grpcserver.h"
#include "mosquittopp.h"


std::vector<Connection*> ConnectionS;
std::vector<ProtocolS::Protocol*> ListenerS;
std::vector<Convert> ConvertS;
ProtocolS::NodeList nodeList;
ERROR::ErrorManager errorManager;
GateWay::LISTENer::Listener ll{};

bool connected;

using namespace GateWay::EVENT::MANAGER;
using namespace GateWay::EVENT::HANDLER;

////////////////////////////////////////////////////////////////////////////////////////////////
void sendRS485()
{
      struct termios tty;
    int hSerial = open("/dev/ttyO4", O_RDWR | O_NOCTTY | O_NDELAY);
    if(hSerial == -1) std::cout<< "Opening of the port failed" << std::endl;
    fcntl(hSerial, F_SETFL, 0);
    if(tcgetattr(hSerial, &tty) != 0) std::cout<< "Getting the parameters failed." <<std::endl;
    if(cfsetispeed(&tty, B9600) != 0 || cfsetospeed(&tty, B9600) != 0) std::cout<<"Setting the baud rate failed."<<std::endl;


    //CFlags
    //Note: I am full aware, that there's an '=', and that it makes the '&=' obsolete, but they're in there for the sake of completeness.
    tty.c_cflag  = (tty.c_cflag & ~CSIZE) | CS8;    //8-bit characters
    tty.c_cflag |= (CLOCAL | CREAD);//und erlaubt 'Lesen'.
    tty.c_cflag &= ~(PARENB | PARODD);          
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CRTSCTS;                    

    //Input Flags
    tty.c_iflag     &= ~IGNBRK;             
    tty.c_iflag &= ~(IXON | IXOFF | IXANY);         

    //Local Flags
    tty.c_lflag  = 0;                   

    //Output Flags
    tty.c_oflag  = 0;

    //Control-Characters
    tty.c_cc[VMIN]   = 0;
    tty.c_cc[VTIME]  = 5;
    if(tcsetattr(hSerial, TCSAFLUSH, &tty) != 0) std::cout<< "Setting the new parameters failed" << std::endl;
    unsigned char C[] = {'H','A','M','I','D'};
    //while(1)
    for(auto c:C)
        write(hSerial,&c, 1); 
    close(hSerial);
}
////////////////////////////////////////////////////////////////////////////////////////////////
class SimpleSerial
{
public:
    /**
     * Constructor.
     * \param port device name, example "/dev/ttyUSB0" or "COM4"
     * \param baud_rate communication speed, example 9600 or 115200
     * \throws boost::system::system_error if cannot open the
     * serial device
     */
    SimpleSerial(std::string port, unsigned int baud_rate)
        : io(), serial(io, port)
    {
        serial.set_option(boost::asio::serial_port_base::baud_rate(baud_rate));
        serial.set_option(boost::asio::serial_port_base::character_size(8));
        serial.set_option(boost::asio::serial_port_base::parity(boost::asio::serial_port_base::parity::none));
    }

    /**
     * Write a string to the serial device.
     * \param s string to write
     * \throws boost::system::system_error on failure
     */
    void writeString(std::string s)
    {
        boost::asio::write(serial, boost::asio::buffer(s.c_str(), s.size()));
    }

    /**
     * Blocks until a line is received from the serial device.
     * Eventual '\n' or '\r\n' characters at the end of the string are removed.
     * \return a string containing the received line
     * \throws boost::system::system_error on failure
     */
    std::string readLine()
    {
        //Reading data char by char, code is optimized for simplicity, not speed
        using namespace boost;
        char c;
        std::string result;
        for (;;)
        {
            asio::read(serial, asio::buffer(&c, 1));
            switch (c)
            {
            case '\r':
                break;
            case '\n':
                return result;
            default:
                result += c;
            }
        }
    }

private:
    boost::asio::io_service io;
    boost::asio::serial_port serial;
};
/////////////////////////////////////////////////////////////////////////

int main()
{
    //sendRS485();

//  try {

//         SimpleSerial serial("/dev/ttyO4", 9600);

//         serial.writeString("Hello world2\n");

//         std::cout << serial.readLine() << std::endl;
        

//     }
//     catch (boost::system::system_error & e)
//     {
//         std::cout << "Error: " << e.what() << std::endl;
//         return 1;
//     }
//      exit(0);
    /////////////////////
    mosqpp::lib_init();
    //system("sudo nmcli d wifi connect Inustry4");
    
    connected = false;

    XmlReader xml;
    std::string path{"../config.xml"};
    ////////////////////////////////////////////////////////////////////
    if (xml.setFile(path)) {
        xml.ExtraConnection(ConnectionS);
        xml.ExtraConvert(ConvertS, ConnectionS);
    }
    
    for (auto i:ConnectionS) {
        std::cout << "\n****************************\n";
        i->print();
        std::cout << "\n****************************\n";
    }

    for (auto i:ConvertS) {
        std::cout << "\n****************************\n";
        i.Print();
        std::cout << "\n****************************\n";
    }

    CONNECTION::ConnectionManager ConnMan;
    std::cout << "config connection manager" << std::endl;
    ConnMan.Create();
    std::cout << "start grpc" << std::endl;
    GrpcServer grpcserver("0.0.0.0:50051" , &ConnMan);

    ///main//
    std::cout << "start event Manager" << std::endl;
    EventManager e_manager{};
    std::cout << "start event handler" << std::endl;
    EventHandler e_handler{};

    std::cout << "bind event manager" << std::endl;
    std::thread e_m(std::bind(&EventManager::Act, &e_manager));
    std::cout << "bind event handler" << std::endl;
    std::thread e_h(std::bind(&EventHandler::Act, &e_handler));

    for (auto l:ListenerS) {
        ll.SetNodes(l);
    }

    ll.ListenLoop();

    std::cout << ".............................\n..........................\n.......................\n" << std::endl;

    std::cout << "after starting, join able: " << e_m.joinable() ;
    e_m.join();
    e_h.join();


    std::cout << "\nHello, World!" << std::endl;
    mosqpp::lib_cleanup();
    return 0;
}
